package com.demo.repo;

/*
 * public interface PostRepo extends JpaRepository<Posts, Integer>{
 * 
 * }
 */